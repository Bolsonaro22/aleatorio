Hi There,
Thank you for downloading my font. 

This font is for PERSONAL USE ONLY !( NOT FOR COMMERCIAL )
The characters in this font for the personal use version are incomplete. For the full character version, you have to buy the commercial version.

If you want to use this font for COMMERCIAL, You need a commercial license that can be purchased in my shop :
https://putracetol.com/
Or
ref/199113/

Or you can provide support to us by making a donation.
Paypal account for donation : https://www.paypal.me/putracetol

Thank you, please support each other :)

If there is a problem, question, or anything about my fonts, please sent an email to putra.designer@gmail.com

Thanks,
PutraCetol Studio

------------------------------------------------------------------------------------------------
HI, WE HAVE 9 FREE FONT FOR YOU WITH COMMERCIAL LICENSE HERE --> https://putracetol.com/freebies/

$1 Deals, Bundle, Discount --> Visit my website --> https://putracetol.com
------------------------------------------------------------------------------------------------

Hai, Terima kasih sudah mendownload font saya.

Font ini hanya untuk penggunaan pribadi (personal) dan tidak untuk penggunaan komersial.
Jika anda ingin menggunakan font ini untuk kebutuhan komersial,anda harus membeli lisensi komersialnya di toko saya :

https://putracetol.com/

Penggunaan font ini untuk komersial tanpa membeli lisensinya terlebih dahulu, akan kami kenakan biaya minimal 5x dari harga lisensi yang seharusnya digunakan.

Terima kasih, mohon saling support :)

Jika ada masalah, pertanyaan atau apapun tentang font saya, silahkan kirim email ke putra.designer@gmail.com

Terima kasih,
PutraCetol Studio